import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, Image, ScrollView, Button } from 'react-native';
import React, { useState, useEffect } from 'react';
import { ref, onValue } from "firebase/database";
import { db } from '../config';

export default function ListView() {
    const [todoData, setTodoData] = useState([]);
    const handlePress = () => {
      alert('Paraplyen er reserveret');
  };
    useEffect(() => {
        const paraplyerRef = ref(db, "Paraplyer/");
        onValue(paraplyerRef, (snapshot) => {
            const data = snapshot.val();
            console.log("data: " + data);
            const newUmbrellas = Object.keys(data).map(key => ({
                id: key,
                ...data[key]
            }));
            setTodoData(newUmbrellas);
        });
    }, []);

    return (
        <View style={styles.container}>
            <Text style={styles.header}>Paraplyer til rådighed:</Text>
            <ScrollView contentContainerStyle={styles.scrollContainer}>
                {todoData.map((item, index) => (
                    <View key={item.id} style={styles.card}>
                        <View style={styles.cardContent}>
                        <Text style={styles.umbrellaCount}>{item.count} Paraplyer</Text>
                        <Text style={styles.umbrellaLocation}>{item.locationName}</Text>
                        <Text style={styles.umbrellaLocation}>Farve: {item.color}</Text>
                        <Button style={styles.button} title="Reserver" onPress={handlePress}/>
                        </View>
                    </View>
                ))}
            </ScrollView>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f0f4f7',
        paddingTop: 50,
    },
    scrollContainer: {
        alignItems: 'center',
        paddingHorizontal: 20,
    },
    header: {
        fontSize: 26,
        fontWeight: 'bold',
        color: '#333',
        marginBottom: 20,
        textAlign: 'center',
    },
    card: {
        backgroundColor: '#fff',
        borderRadius: 10,
        shadowColor: '#000',
        shadowOpacity: 0.1,
        shadowRadius: 10,
        elevation: 5,
        padding: 20,
        marginVertical: 10,
        width: '100%',
        maxWidth: 350,
    },
    cardContent: {
        alignItems: 'center',
    },
    umbrellaCount: {
        fontSize: 22,
        fontWeight: 'bold',
        color: '#4a4a4a',
        marginBottom: 10,
    },
    umbrellaLocation: {
        fontSize: 18,
        color: '#7a7a7a',
        marginBottom: 10,
    },
    umbrellaColor: {
        padding: 5,
        borderRadius: 5,
        color: '#fff',
        fontWeight: 'bold',
        fontSize: 16,
        textTransform: 'capitalize',
        textAlign: 'center',
        width: 120,
    },
    button: {
      padding: 5,
      borderRadius: 5,
      color: 'red',
      fontWeight: 'bold',
      fontSize: 16,
      textTransform: 'capitalize',
      textAlign: 'center',
      width: 120,
  },
});