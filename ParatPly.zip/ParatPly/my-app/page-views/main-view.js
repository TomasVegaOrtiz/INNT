import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, Image, Button, TouchableOpacity } from 'react-native';
import React from 'react';


export default function MainView(){
    return (
        <View style={styles.container}>
            <Text>Velkommen til din ParatPly profil</Text>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#89CFF0',
      alignItems: 'center',
      justifyContent: 'center',
    },
})