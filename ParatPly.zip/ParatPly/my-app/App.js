// impotere de komponenter de nødvendige komponenter, samme gøres for de andre views.
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, Image, Button, TouchableOpacity } from 'react-native';
import {React,useState,useEffect} from 'react';
import ListView from './page-views/list-view';
import MainView from './page-views/main-view';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs'
import { NavigationContainer } from '@react-navigation/native';
import MapContainerView from './page-views/map-view';
import CameraContainerView from './page-views/camera-view';


// Opretter tab navigationen
const Tab = createBottomTabNavigator(); 

export default function App() {



  return (
    // Laver en bottom bar som er appens hovedkomponent
    <View style={styles.container}>
      <NavigationContainer> 
        <Tab.Navigator> 
          <Tab.Screen name="List" component={ListView} />
          <Tab.Screen name="Map" component={MapContainerView} />
          <Tab.Screen name="Profile" component={MainView} />
          <Tab.Screen name="Camera" component={CameraContainerView}></Tab.Screen>
        </Tab.Navigator>

      </NavigationContainer>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#89CFF0',
  },
});
